import React, { useState } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { Users, MessageSquare } from 'lucide-react';

const ChatApp = () => {
  const { connected } = useWallet();
  const [activeChat, setActiveChat] = useState<string | null>(null);
  
  if (!connected) {
    return (
      <div className="bg-white rounded-lg p-8 text-center">
        <MessageSquare className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <h2 className="text-2xl font-semibold text-gray-700 mb-2">
          Connect Your Wallet to Start Chatting
        </h2>
        <p className="text-gray-500">
          Earn tokens by having meaningful conversations with new people!
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-12 gap-6">
      {/* Users List */}
      <div className="col-span-4 bg-white rounded-lg shadow-lg p-4">
        <div className="flex items-center space-x-2 mb-4">
          <Users className="w-5 h-5 text-purple-600" />
          <h2 className="text-lg font-semibold">Online Users</h2>
        </div>
        <div className="space-y-2">
          {/* Placeholder users - will be replaced with real data */}
          {['User 1', 'User 2', 'User 3'].map((user) => (
            <div
              key={user}
              onClick={() => setActiveChat(user)}
              className={`p-3 rounded-lg cursor-pointer transition-colors ${
                activeChat === user
                  ? 'bg-purple-100 text-purple-700'
                  : 'hover:bg-gray-100'
              }`}
            >
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 rounded-full bg-green-500" />
                <span>{user}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Chat Area */}
      <div className="col-span-8 bg-white rounded-lg shadow-lg p-4">
        {activeChat ? (
          <>
            <div className="h-[500px] overflow-y-auto mb-4 p-4 bg-gray-50 rounded-lg">
              {/* Messages will go here */}
              <div className="text-center text-gray-500">
                Start chatting to earn tokens!
              </div>
            </div>
            <div className="flex space-x-2">
              <input
                type="text"
                placeholder="Type your message..."
                className="flex-1 p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
              <button className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                Send
              </button>
            </div>
          </>
        ) : (
          <div className="h-full flex items-center justify-center text-gray-500">
            Select a user to start chatting
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatApp;