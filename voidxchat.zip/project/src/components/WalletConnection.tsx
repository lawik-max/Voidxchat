import React from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { Coins } from 'lucide-react';

const WalletConnection = () => {
  const { connected, publicKey } = useWallet();
  const tokens = 0; // This will be replaced with actual token balance

  return (
    <div className="bg-white rounded-lg p-6 mb-8 shadow-lg">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <WalletMultiButton className="!bg-purple-600 hover:!bg-purple-700" />
          {connected && (
            <p className="text-gray-600">
              {publicKey?.toString().slice(0, 4)}...
              {publicKey?.toString().slice(-4)}
            </p>
          )}
        </div>
        {connected && (
          <div className="flex items-center space-x-2">
            <Coins className="w-5 h-5 text-purple-600" />
            <span className="font-semibold text-purple-600">{tokens} tokens</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default WalletConnection;