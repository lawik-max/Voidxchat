import React, { useMemo } from 'react';
import {
  ConnectionProvider,
  WalletProvider,
} from '@solana/wallet-adapter-react';
import { WalletModalProvider } from '@solana/wallet-adapter-react-ui';
import { PhantomWalletAdapter } from '@solana/wallet-adapter-wallets';
import { clusterApiUrl } from '@solana/web3.js';
import { MessageCircle } from 'lucide-react';
import ChatApp from './components/ChatApp';
import WalletConnection from './components/WalletConnection';
import '@solana/wallet-adapter-react-ui/styles.css';

function App() {
  const endpoint = useMemo(() => clusterApiUrl('devnet'), []);
  const wallets = useMemo(() => [new PhantomWalletAdapter()], []);

  return (
    <ConnectionProvider endpoint={endpoint}>
      <WalletProvider wallets={wallets} autoConnect>
        <WalletModalProvider>
          <div className="min-h-screen bg-gradient-to-br from-purple-500 to-pink-500">
            <div className="container mx-auto px-4 py-8">
              <div className="flex items-center justify-center mb-8">
                <MessageCircle className="w-10 h-10 text-white mr-2" />
                <h1 className="text-4xl font-bold text-white">SolChat Rewards</h1>
              </div>
              <WalletConnection />
              <ChatApp />
            </div>
          </div>
        </WalletModalProvider>
      </WalletProvider>
    </ConnectionProvider>
  );
}

export default App;